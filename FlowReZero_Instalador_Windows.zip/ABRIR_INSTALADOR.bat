@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar_Flow_Windows.ps1"
if errorlevel 1 pause
